# KSSK/PWr LaTeX Poster Theme

[KSSK](https://kssk.pwr.edu.pl) Theme based on _Gemini_ Theme (with much appreciation).

## License

Released under the MIT License.

[Gemini]: https://anishathalye.com/gemini-a-modern-beamerposter-theme
[beamerposter]: https://github.com/deselaers/latex-beamerposter
[Auriga]: https://github.com/anishathalye/auriga
[LuaTeX]: http://www.luatex.org/
[CTAN]: https://ctan.org/
[Raleway]: https://www.fontsquirrel.com/fonts/raleway
[Lato]: https://www.fontsquirrel.com/fonts/lato
[license]: LICENSE.md
[FAQ]: https://github.com/anishathalye/gemini/wiki/FAQ
